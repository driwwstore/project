from driwvpn import *
#DELETE SSH
@bot.on(events.CallbackQuery(data=b'delete-ssh'))
async def delete_ssh(event):
	async def delete_ssh_(event):
		async with bot.conversation(chat) as user:
			await event.respond("**Username To Be Deleted:**")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
			cmd = f'printf "%s\n" "{user}" | bot-delssh'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond(f"**User** `{user}` **Not Found**")
		else:
			await event.respond(f"**Successfully Deleted** `{user}`")
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await delete_ssh_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

#CRATE SSH
@bot.on(events.CallbackQuery(data=b'create-ssh'))
async def create_ssh(event):
	async def create_ssh_(event):
		async with bot.conversation(chat) as user:
			await event.respond(f"""
**⚠️ ɴᴏ ꜱᴘᴀᴄᴇ**
**⚠️ ɴᴏ ᴅᴏᴜʙʟᴇ ɴᴀᴍᴇ**

**👉 ɪɴᴘᴜᴛ ʏᴏᴜʀ ᴜꜱᴇʀɴᴀᴍᴇ :**
""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as pw:
			await event.respond(f"""
**⚠️ ɴᴏ ꜱᴘᴀᴄᴇ**

**👉 ɪɴᴘᴜᴛ ʏᴏᴜʀ ᴘᴀꜱꜱᴡᴏʀᴅ :**
""")
			pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			pw = (await pw).raw_text
		async with bot.conversation(chat) as exp:
			await event.respond("**Choose Expiry Day**",buttons=[
[Button.inline(" 1 Day ","1"),
Button.inline(" 2 Day ","2"),
Button.inline(" 3 Day ","3")],
[Button.inline(" 4 Day ","4"),
Button.inline(" 5 Day ","5"),
Button.inline(" 6 Day ","6")],
[Button.inline(" 7 Day ","7"),
Button.inline(" 30 Day ","30"),
Button.inline(" 60 Day ","60")]])
			exp = exp.wait_event(events.CallbackQuery)
			exp = (await exp).data.decode("ascii")
		await event.edit("`Wait.. Setting up an Account`")
		cmd = f'printf "%s\n" "{user}" "{pw}" "{exp}" | bot-addssh'
		try:
			subprocess.check_output(cmd,shell=True)
		except:
			await event.respond("**User Already Exist**")
		else:
			today = DT.date.today()
			later = today + DT.timedelta(days=int(exp))
			msg = f"""
**◇━━━━━━━━━━━━━━━━━◇**
**     ⟨  SSH OVPN Account ⟩**
**◇━━━━━━━━━━━━━━━━━◇**
**» `Username         :`** `{user.strip()}`
**» `Password         :`** `{pw.strip()}`
**◇━━━━━━━━━━━━━━━━━◇**
**» `Host             :`** `{DOMAIN}`
**» `Port OpenSSH     :`** `443, 80, 22`
**» `Port Dropbear    :`** `443, 109`
**» `Port Dropbear WS :`** `443, 109`
**» `Port SSH WS      :`** `80, 8080 `
**» `Port SSH SSL WS  :`** `443`
**» `Port SSL/TLS     :`** `443`
**» `Port OVPN WS SSL :`** `443`
**» `Port OVPN SSL    :`** `443`
**» `Port OVPN TCP    :`** `443, 1194`
**» `Port OVPN UDP    :`** `2200`
**» `Port UDP Custom   :`** `1-65535`
**» `Proxy Squid      :`** `3128`
**» `BadVPN UDP       :`** `7100, 7300, 7300`
**◇━━━━━━━━━━━━━━━━━◇**
**      PAYLOAD WS PORT 80      ** 
**◇━━━━━━━━━━━━━━━━━◇**
`GET / HTTP/1.1[crlf]Host: [host][crlf]Connection: Keep-Alive[crlf]User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]`
**◇━━━━━━━━━━━━━━━━━◇**
**    PAYLOAD WSS PORT 443      ** 
**◇━━━━━━━━━━━━━━━━━◇**
`GET wss://BUG.COM/ HTTP/1.1[crlf]Host: [host][crlf]Connection: Keep-Alive[crlf]User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]`
**◇━━━━━━━━━━━━━━━━━◇**
**            LINK OVPN      ** 
**◇━━━━━━━━━━━━━━━━━◇**
https://{DOMAIN}:81
**◇━━━━━━━━━━━━━━━━━◇**
**» 🗓️ Expired Until:** `{later}`
**» 🤖 @tau_samawa**
**◇━━━━━━━━━━━━━━━━━◇**
"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await create_ssh_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'show-ssh'))
async def show_ssh(event):
	async def show_ssh_(event):
		cmd = 'bot-member-ssh'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""
```
{z}
```
**Show All SSH User**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await show_ssh_(event)
	else:
		await event.answer("Access Denied",alert=True)



@bot.on(events.CallbackQuery(data=b'trial-ssh'))
async def trial_ssh(event):
	async def trial_ssh_(event):
		user = "trialX"+str(random.randint(100,1000))
		pw = "1"
		exp = "1"
		cmd = f'useradd -e `date -d "{exp} days" +"%Y-%m-%d"` -s /bin/false -M {user} && echo "{pw}\n{pw}" | passwd {user} | echo "killtrial ssh {user}" | at now +60 minutes &> /dev/null'
		try:
			subprocess.check_output(cmd,shell=True)
		except:
			await event.respond("**User Already Exist**")
		else:
			#today = DT.date.today()
			#later = today + DT.timedelta(days=int(exp))
			msg = f"""
**◇━━━━━━━━━━━━━━━━━◇**
**     ⟨  SSH OVPN Account ⟩**
**◇━━━━━━━━━━━━━━━━━◇**
**» `Username         :`** `{user.strip()}`
**» `Password         :`** `{pw.strip()}`
**◇━━━━━━━━━━━━━━━━━◇**
**» `Host             :`** `{DOMAIN}`
**» `Port OpenSSH     :`** `443, 80, 22`
**» `Port Dropbear    :`** `443, 109`
**» `Port Dropbear WS :`** `443, 109`
**» `Port SSH WS      :`** `80, 8080 `
**» `Port SSH SSL WS  :`** `443`
**» `Port SSL/TLS     :`** `443`
**» `Port OVPN WS SSL :`** `443`
**» `Port OVPN SSL    :`** `443`
**» `Port OVPN TCP    :`** `443, 1194`
**» `Port OVPN UDP    :`** `2200`
**» `Port UDP Custom   :`** `1-65535`
**» `Proxy Squid      :`** `3128`
**» `BadVPN UDP       :`** `7100, 7300, 7300`
**◇━━━━━━━━━━━━━━━━━◇**
**      PAYLOAD WS PORT 80      ** 
**◇━━━━━━━━━━━━━━━━━◇**
`GET / HTTP/1.1[crlf]Host: [host][crlf]Connection: Keep-Alive[crlf]User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]`
**◇━━━━━━━━━━━━━━━━━◇**
**    PAYLOAD WSS PORT 443      ** 
**◇━━━━━━━━━━━━━━━━━◇**
`GET wss://BUG.COM/ HTTP/1.1[crlf]Host: [host][crlf]Connection: Keep-Alive[crlf]User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]`
**◇━━━━━━━━━━━━━━━━━◇**
**            LINK OVPN      ** 
**◇━━━━━━━━━━━━━━━━━◇**
https://{DOMAIN}:81
**◇━━━━━━━━━━━━━━━━━◇**
**» 🗓️ Expired Until:** `60 Minutes`
**» 🤖 @tau_samawa**
**◇━━━━━━━━━━━━━━━━━◇**
"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await trial_ssh_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)
		
@bot.on(events.CallbackQuery(data=b'login-ssh'))
async def login_ssh(event):
	async def login_ssh_(event):
		cmd = 'bot-cek-login-ssh'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""

{z}

**shows logged in users SSH Ovpn**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await login_ssh_(event)
	else:
		await event.answer("Access Denied",alert=True)

#RENEW SSH
@bot.on(events.CallbackQuery(data=b'renew-ssh'))
async def ren_ssh(event):
	async def ren_ssh_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**Username:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as exp:
			await event.respond("**Choose Expiry Day**",buttons=[
[Button.inline(" 1 Day ","1"),
Button.inline(" 2 Day ","2"),
Button.inline(" 3 Day ","3")],
[Button.inline(" 4 Day ","4"),
Button.inline(" 5 Day ","5"),
Button.inline(" 6 Day ","6")],
[Button.inline(" 7 Day ","7"),
Button.inline(" 30 Day ","30"),
Button.inline(" 60 Day ","60")]])
			exp = exp.wait_event(events.CallbackQuery)
			exp = (await exp).data.decode("ascii")
		cmd = f'printf "%s\n" "{user}" {exp}| bot-renewssh'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**User Not Found**")
		else:
			msg = f"""**Successfully Renewed  {user} {exp} Days**"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await ren_ssh_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)
		
@bot.on(events.CallbackQuery(data=b'ssh'))
async def ssh(event):
	async def ssh_(event):
		inline = [
[Button.inline("✨ ᴛʀɪᴀʟʟ ꜱꜱʜ ✨","trial-ssh"),
Button.inline("✨ ᴄʀᴇᴀᴛᴇ ꜱꜱʜ ✨","create-ssh")],
[Button.inline("✨ ᴅᴇʟᴇᴛᴇ ꜱꜱʜ ✨","delete-ssh"),
Button.inline("✨ ᴄᴇᴄᴋ ᴜꜱᴇʀ ʟᴏɢɪɴ ✨","login-ssh")],
[Button.inline("✨ ᴍᴇᴍʙᴇʀ ꜱꜱʜ ✨","show-ssh")],
[Button.inline("✨ ʀᴇɴᴇᴡ ꜱꜱʜ ✨","renew-ssh"),
Button.inline("🔙ᴍᴀɪɴ ᴍᴇɴᴜ","menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		sh = f' cat /etc/ssh/.ssh.db | grep "###" | wc -l'
		ssh = subprocess.check_output(sh, shell=True).decode("ascii")
		msg = f"""
**═══════════════**
**❖ ꜱꜱʜ ᴏᴠᴘɴ ᴍᴀɴᴀɢᴇʀ ❖**
**═══════════════**
**» 🔸ꜱᴇʀᴠɪᴄᴇ:** `ꜱꜱʜ ᴏᴠᴘɴ`
**» 🔸ʜᴏꜱᴛɴᴀᴍᴇ/ɪᴘ:** `{DOMAIN}`
**» 🔸ɪꜱᴘ:** `{z["isp"]}`
**» 🔸ᴄᴏᴜɴᴛʀʏ:** `{z["country"]}`
**» 🔸ꜱꜱʜ ᴀᴄᴄᴏᴜɴᴛ :** `{ssh.strip()}`
**═══════════════**
"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await ssh_(event)
	else:
		await event.answer("Access Denied",alert=True)
